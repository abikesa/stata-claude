stata_project/
├── config.do           ← contains all globals + options
├── just-click.do       ← core logic calls config
├── data/               ← data files
├── output/             ← log + graphs
├── code/               ← additional sub-scripts if needed
├── notes/              ← lab notes, etc.

